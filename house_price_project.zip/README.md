# End-to-End House Price Prediction (XGBoost)

## Project Overview
This project implements an end-to-end machine learning pipeline to predict house prices using structured tabular data.
The workflow follows industry best practices including data preprocessing, feature engineering, model tuning,
and evaluation using cross-validation.

The goal is to build a **leakage-free, production-ready ML pipeline** suitable for real-world deployment and
recruiter evaluation.

---

## Dataset
- Structured housing dataset (numerical + categorical features)
- Missing values handled using statistical imputation
- Categorical variables encoded using One-Hot Encoding

---

## Machine Learning Pipeline
- **Preprocessing**:  
  - Numerical: Median imputation + Standard scaling  
  - Categorical: Most-frequent imputation + One-hot encoding  
- **Model**: XGBoost Regressor
- **Hyperparameter Tuning**: RandomizedSearchCV
- **Validation**: 5-Fold Cross-Validation
- **Metric**: Root Mean Squared Error (RMSE)

---

## Model Performance

| Model | Validation Strategy | RMSE |
|------|---------------------|------|
| Tuned XGBoost | 5-Fold CV | XX.XX |

---

## Key Insights
- Pipeline-based preprocessing prevents data leakage
- Hyperparameter tuning significantly improves generalization
- XGBoost handles non-linear interactions effectively in tabular data
- Modular code structure improves reproducibility and scalability

---

## Project Structure
