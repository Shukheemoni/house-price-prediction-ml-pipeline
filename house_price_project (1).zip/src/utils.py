
import numpy as np
from sklearn.model_selection import cross_val_score


def cross_val_rmse(model, x, y, cv=5):
    scores = cross_val_score(
        model,
        x,
        y,
        cv=cv,
        scoring="neg_root_mean_squared_error",
        n_jobs=-1
    )
    return -scores.mean(), scores.std()
